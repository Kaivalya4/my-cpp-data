/**
Leetcode - find smallest letter greater than target
*/
#include<iostream>

using namespace std;

int main()
{
    cout << "thank you" ;
    return 0;
}
