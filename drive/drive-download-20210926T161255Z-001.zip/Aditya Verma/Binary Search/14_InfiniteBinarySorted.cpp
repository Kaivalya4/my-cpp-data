///Find the index of first element of infinite sorted binary array
#include<iostream>

using namespace std;

/**
int arr[infinite];

void solve(int n)
{
    int low =0 , high = 1;
    while(arr[high]!=1)
    {
        low = high;
        high = high*2;
    }
    int res = -1;
    while(low<=high)
    {
        int mid= low+(high-low)/2;
        if(arr[mid] == 1 )
        {
            res  = mid;
            high = mid-1;
        }
        else
        {
            start = mid+1;
        }
    }
}
*/
int main()
{
    cout << "Thank you";
    return 0;
}
