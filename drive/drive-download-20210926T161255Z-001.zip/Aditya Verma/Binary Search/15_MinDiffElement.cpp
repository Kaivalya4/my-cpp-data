///problem link not found . But this problem is easy

#include<iostream>

using namespace std;

int main()
{
    cout << "Thank You";
    return 0;
}
