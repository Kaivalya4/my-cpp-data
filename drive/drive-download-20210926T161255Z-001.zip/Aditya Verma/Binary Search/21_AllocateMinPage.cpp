///practise.gfg  - allocate minimum number of pages
#include<iostream>

using namespace std;

int main()
{
    cout << "Thank You" ;
    return 0;
}

