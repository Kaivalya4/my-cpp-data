///leet code - search element in rotated sorted array.

#include<iostream>

using namespace std;

int main()
{
    cout << "Thank You" ;
    return 0;
}
