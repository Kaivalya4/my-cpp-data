///1 is theory
///Kth smallest element in an array - gfg.practise
/// method1 - sort
///method2 - maxheap
/**
->stl libraries were not included in the driver code . So cant use sort() or priority_queue
->tried implementing pq but code has some bug
->Implemented merge sort and got the answer
*/
#include<iostream>

using namespace std;

int main()
{
    cout << "Thank you";
    return 0;
}
