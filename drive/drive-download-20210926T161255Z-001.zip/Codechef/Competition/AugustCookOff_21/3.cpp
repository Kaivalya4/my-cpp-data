/**
Important points -
If we use set theory it will take O(n^2) time.(checking all pairs -> a*b is closed or not where * is operator)

Important points -
-> if only possible element are -1 ,0 , 1
    -> if number of -1 is more than one but there is no 1 => o/p = 0
    -> if -1 is not there => possible elements = 0,1 => o/p = 1
-> if number of element greter than 1 are more than one
    or ,if number of element lower than -1 are more than one
    then o/p = 0
-> if numbers of number > 1 is only one .
    -> no -ve element should be there
-> if numbers of number <-1 is only one
    -> no -1 and no positive > 1 should be there
*/
#include<bits/stdc++.h>

using namespace std;

long long arr[1000001];

int main()
{
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        int ctr = 0;
        int ctr1 = 0;
        int ctr2 = 0;
        int ne = 0;
        int po = 0;
        long long zero = 0;
        bool flag = false;
        for(int i=0;i<n;i++)
        {
            cin >> arr[i];
            if(arr[i]>1)
                po++;
            if(arr[i] < -1)
                ne++;
            if(arr[i] == 1)
                ctr2++;
            if(arr[i] == 0)
                ctr++;
            if(arr[i] == -1)
                ctr1++;
        }
        if(n ==1)
        {
            cout << 1 << endl;
            continue;
        }
        ///if there are no element greater than 1
        ///no element lower than -1
        if(po == 0 && ne == 0)
        {
            ///then if number of -1 is more than one
            if(ctr1 >1){
                    ///then 1 should be there
                if(ctr2 == 0)
                    cout << 0 << endl;
                else
                    cout << 1 << endl;
                continue;
            } /// number of -1 is either one or less
            else{
                cout << 1 << endl;
                continue;
            }

        }
        ///If there are numbers present greater than 1
        if(po >1 || ne > 1)
        {
            cout << 0 << endl;
            continue;
        }
        if(po == 1 )
        {
            if(ne == 0 && ctr1 == 0){
                cout << 1 << endl;
                continue;
                }
            else{
                cout << 0 << endl;
                continue;
            }

        }
        if(ne == 1)
        {
            if(po == 0 && ctr1 == 0 )
            {
                cout << 1 << endl;
                continue;
            }
            else{
                cout << 0 << endl;
                continue;
            }
        }
    }
    return 0;
}
