#include<bits/stdc++.h>

using namespace std;

long long arr[500001];

int main()
{
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        for(int i=0;i<n;i++){
            cin >> arr[i];
        }
        if(n==1)
        {
            cout << 0 << endl;
            continue;
        }
        if(n == 2)
        {
            cout << 0 << endl;
            continue;
        }
        unordered_map<long , int> umap;
        int maxi = 0;
        for(int i=0;i<n;i++)
        {
            umap[arr[i]] ++;
        }
        for(auto i:umap)
        {
            maxi = max(maxi , i.second);
        }
        if(maxi == 1)
        {
            cout << n-2 << endl;
        }
        else{
            cout << n - maxi << endl;
        }
    }
    return 0;
}
