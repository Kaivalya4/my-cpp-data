/**
Read Pigeonhole Principle first.
Now if n=100 , then length of string is 100 and number of string is hundred . But there are 2power 100
possible string of length 10 .
Basic idea - so if n is given then why not generate n+1 strings . Even if all n strings matched with
our given string we will have one string which will not match any of the given string

How I generated the random strings?
First of all 00000 is also valid answer.
suppose n = 5.
lets make a string 00000
                   10000
                   11000
                   11100
                   11110
                   11111  -> see we able to generate 6 strings
so my way of generation - fill 1 from left to right at a time and check.
*/
#include<bits/stdc++.h>

using namespace std;

bool comp(pair<int, int> a, pair<int ,int>b)
{
    return a.first < b.first;
}

int main()
{
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        string ip;
        string op;
        vector<string> vec;
        unordered_map<string  , bool> umap;
        for(int i=0;i<n;i++){
            cin >> ip;
            vec.push_back(ip);
            umap[ip] = true;
            op.push_back('0');
        }
        if(umap[op] == false)
        {
            cout << op << endl;
            continue;
        }
        for(int i=0;i<n;i++)
        {
            op[i] = '1';
            if(umap[op] == false)
            {
                cout << op << endl;
                break;
            }
        }
    }
    return 0;
}
