/**
Suppose that a flock of 20 pigeons flies into a set of 19 pigeonholes to roost.
Because there are 20 pigeons but only 19 pigeonholes, a least one of these 19 pigeonholes
must have at least two pigeons in it.
*/

#include<iostream>

using namespace std;

int main(){
    cout << "thank you";
    return 0;
}
