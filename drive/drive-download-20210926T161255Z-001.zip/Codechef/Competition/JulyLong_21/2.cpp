#include<bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int g,c;
        cin >> g >> c;
        int val1 = c*c;
        int val2  = val1 /(2*g) ;
        cout << val2 << endl;
    }
    return 0;
}
