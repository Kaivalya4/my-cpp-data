///marked

#include<bits/stdc++.h>

using namespace std;

vector<long> arr;
vector<long> store;
long sizes =0;

void decToBin(long val)
{
    long ctr =0;
    while(val > 0)
    {
        store[ctr++] += val%2;
        val = val/2;
    }
    sizes = max(sizes , ctr);
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        long k;
        cin >> n;
        cin >> k;
        arr.clear();
        for(int i=0;i<n;i++)
        {
            long val;
            cin >> val;
            arr.push_back(val);
        }
        store.clear();
        for(int i=0;i<51;i++)
        {
            store.push_back(0);
        }
        for(int i=0;i<n;i++)
        {
            decToBin(arr[i]);
        }
        long ans =0;
        for(long  i=0 ;i<sizes; i++)
        {
            ans += ceil(store[i]/(float)k) ;
        }
        cout << ans << endl;
    }
    return 0;
}
