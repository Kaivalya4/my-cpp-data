#include<bits/stdc++.h>

using namespace std;

vector<int> adj[100001];
int vis[100001];
int counts[100001];
unordered_map<int , int> umap;
string ans;

int dfs(int node )
{
    vis[node] =1;
    if(ans == "YES")
        return 0;
    for(int i=0;i<adj[node].size();i++)
    {
        int child = adj[node][i];
        if(vis[child] == 0)
        {
            int ctr = 0;
            int val = dfs(child);
            if(val !=0)
                ctr++;
            counts[node] += val;
        }
    }
    if(umap[counts[node]] == 1)
        counts[node] += 1;
    if(counts[node] == umap.size())
        ans = "YES" ;
    return counts[node];
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        int m = n-1;
        while(m--)
        {
            int u ,v;
            cin >> u >> v;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
        int q;
        cin >> q;
        while(q--)
        {
            umap.clear();
            int k;
            cin >> k;
            while(k--)
            {
                int v;
                cin >> v;
                umap[v] = 1;
            }
            ans = "NO";
            dfs(1);
            cout << ans << endl;
        }
    }
    return 0;
}
