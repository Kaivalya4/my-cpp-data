///marked

#include<bits/stdc++.h>

using namespace std;

long long mod = 1000000007;

vector<long> vec;
vector<long  long> pre;

long genPalin(long val , long ten)
{
    long tens = 10;
    long num = val;
    val = val/tens;
    long rev = 0;
    while(val)
    {
        long rem = val%10;
        rev = rev *10 + rem;
        val = val/10;
    }
    num = num * ten;
    num = num + rev;
    return num;
}

void create()
{
    vec.push_back(0);
    for(long  i=1;i<=9;i++)
        vec.push_back(i);
    for(long i=10 ;i<=99 ;i++)
    {
        long ten = 10;
        vec.push_back(genPalin(i,ten));
    }
    for(long  i=100;i<=999;i++)
    {
        long ten = 100;
        vec.push_back(genPalin(i,ten));
    }
    for(long i=1000;i<=9999;i++)
    {
        long ten = 1000;
        vec.push_back(genPalin(i,ten));
    }
    for(long i=10000;i<=99999;i++){
        long ten = 10000;
        vec.push_back(genPalin(i,ten));

    }
    long ten = 100000;
    vec.push_back(genPalin(100000,ten));
}

void prefix()
{
    pre.push_back(0);
    pre.push_back(1);
    for(int i=2;i<vec.size();i++)
    {
        pre.push_back(0);
        pre[i] = vec[i] + pre[i-1];
    }
}

int expo(long long a , long long n )
{
    long res = 1;
    while(n>0)
    {
        if(n%2)
        {
            res = (res *a)%mod;
            n--;
        }
        a= (a*a) %mod;
        n = n/2;
    }
    return res;
}

int main()
{
    create();
    prefix();
    int q;
    cin >> q;
    while(q--)
    {
        int l,r;
        cin >> l >> r;
        long sum = pre[r] - pre[l];
        long val = expo(vec[l] ,sum ) %mod;
        cout << val << endl;
    }
    return 0;
}
