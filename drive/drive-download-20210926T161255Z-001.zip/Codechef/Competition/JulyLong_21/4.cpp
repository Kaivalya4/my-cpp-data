///marked
#include<bits/stdc++.h>

using namespace std;

long gcd(long a , long b)
{
    if(b == 0)
        return a;
    else
        return gcd(b,a%b);
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        long sum =0;
        vector<long> arr;
        for(int i=0;i<n;i++){
            long val;
            cin >> val;
            arr.push_back(val);
            sum += val;
        }
        if(n==1){
            cout << 1 << endl;
            continue;
        }
        vector<long> GCDL;
        GCDL.push_back(0);
        for(int i=1;i<n ;i++)
        {
            GCDL.push_back(gcd(arr[i-1] , GCDL[i-1]));
        }
        vector<long> GCDR(n,0);
        for(int i=n-2;i>=0;i--)
        {
            GCDR[i] = gcd(arr[i+1] , GCDR[i+1]);
        }
        long ans = LONG_MAX;
        for(int i=0;i<n;i++)
        {
            long temp = gcd(GCDL[i],GCDR[i]);
            long temp1 = sum - arr[i] + temp;
            temp1 = temp1 /temp;
            ans = min(ans ,temp1);
        }

        cout << ans<< "\n";
    }
    return 0;
}
