#include<iostream>

using namespace std;


///ITERATIVE METHOD - O(logn) time
bool checkPalindrome1(int n)
{
    int rev =0;
    int x = n;
    while(n)
    {
        /// this will store the last digit of `n` in variable `rem`
        /// e.g. if `n` is 1234, then `rem` would be 4
        int rem = n%10;

        /// add `rem` to `rev` in one's place
        /// e.g. if `rev = 65` and `rem = 4`, then new `rev` would be 654
        rev = rev * 10 + rem; //first digit of n is find out and kept multiplying with 10 to make it last digit

        /// remove the last digit from `n`
        /// e.g. if `n` is 1234, then the new `n` would be 123
        n = n/10;
    }
    if(x == rev)
        return true;
    return false;
}


bool check(int rev , int n , int N)
{
    if(n == 0)
    {
        if(rev == N)
            return true;
        return false;
    }
    rev = (rev*10) + (n%10);
    return check(rev , n/10 , N);
}

bool checkPalindrome2(int n)
{
    return check(0 , n , n);
}

int main()
{
    int n;
    cin >> n;
    if(checkPalindrome1(n))
        cout << "Number is Palindrome." << endl ;
    else
        cout << "Number is not Palindrome." << endl;

    if(checkPalindrome2(n))
        cout << "Number is Palindrome." << endl ;
    else
        cout << "Number is not Palindrome." << endl;
    return 0;
}
