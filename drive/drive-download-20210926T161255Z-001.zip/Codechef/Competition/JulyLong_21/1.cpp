#include<bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int d,x,y,z;
        cin >> d >> x >> y >> z;
        int val1 = x*7;
        int val2 = (y*d) + ((7-d)*z);
        cout << max(val1 , val2) << endl;
    }
    return 0;
}
