#include<iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long counts = 0;
        long a ;
        cin >> a;
        while(a!=0)
        {
            if(a%10 == 4)
                counts++;
            a= a/10;
        }
        cout << counts << endl;
    }
    return 0;
}
