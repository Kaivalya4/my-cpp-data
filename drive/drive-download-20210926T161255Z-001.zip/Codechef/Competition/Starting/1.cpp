#include<iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int maxs = 1;
    for(int i=2; i<=10 && i<=n ;i++)
    {
        if(n%i == 0)
            maxs = max(maxs , i);
    }
    cout << maxs ;
    return 0;
}
