#include<bits/stdc++.h>

using namespace std;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n , k;
		cin >> n >> k;
		string arr;
		cin >> arr;
		int counts = 0;
		for(int i=1;i<n;i++)
		{
			if(arr[i] != arr[i-1])
			{
				counts++;
			}
		}
		if(counts<k)
			cout << -1 ;
		else{
			char start = arr[0];
			for(int i=n-1;i>=1;i--)
			{
				if(arr[i] == start && k%2 == 0){
					cout << i+1;
					break;
				}
				else if(arr[i] != start && k%2!=0){
					cout << i+1;
					break;
				}
				
			}
		}
		cout << endl;
	}
	return 0;
}