#include<bits/stdc++.h>

using namespace std;

int arr[1000001];

int main()
{
	int t;
	cin >>t;
	while(t--){
		int n , odd = 0;
		cin >> n;
		for(int i=0;i<n;i++)
		{
			cin >> arr[i];
			if(arr[i]%2 !=0)
				odd++;
		}
		if(odd == 0 || odd == n)
		{
			cout << -1 << endl;
			continue;
		}
		for(int i=0;i<n;i++)
			if(arr[i] %2 == 0)
				cout << arr[i] << " ";
		for(int i=0;i<n;i++)
			if(arr[i] %2 !=0)
				cout << arr[i] << " ";
		cout << endl;
	}
	return 0;
}