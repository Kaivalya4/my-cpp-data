#include<bits/stdc++.h>

using namespace std;
unordered_map<int,bool> umap;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		long k;
		long long sum = 0;
		cin >> n >> k;
		vector<int> vec;
		for(int i=0;i<n;i++)
		{
			int val;
			cin >> val;
			vec.push_back(val);
			if(val > 0)
				umap[i] = true;
			sum += val;
		}
		while(umap.size()<n && k >0)
		{
			sum += (umap.size())*2;
			vector<int> temp;
			for(auto i:umap)
				temp.push_back(i.first);
			for(auto i:temp)
			{
				int left = (i - 1 + n)%n;
				int right = (i +1  + n) %n;
				umap[left] = true;
				umap[right] = true;
			}
			k--;
		}
		sum += k*(2 * umap.size()) ;
		cout << sum << endl;
		umap.clear();
	}
	return 0;
}