#include<bits/stdc++.h>

using namespace std;
int mod = 1000000001;
int bound = 100000;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		vector<int> arr;
		for(int i=0;i<n-1;i++)
		{
			int val;
			cin >> val;
			arr.push_back(val);
		}
		n--;
		long long sum = 0;
		if(n<=2)
		{
			sum += (bound - arr[n-1]);
			sum += sum +1;
			sum = sum %mod;
			cout << sum << endl;
			continue;
		}
		cout << 1;
		for(int i=0;i<n-1;i++)
		{
			if(arr[i]<=arr[i+1])
			{
				sum += (bound - arr[i+1]);
				sum = sum %mod;
			}
		}
		sum += (bound - arr[n-1]);
		sum = sum %mod;
		cout << sum << endl;
	}
	return 0;
}