#include<bits/stdc++.h>

using namespace std;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		long long  n , s;
		cin >> n >> s;
		long long sum = (n * (n+1))/2;
		long long x = sum - s;
		if(x>=1 && x <=n)
			cout << x << " " << endl;
		else
			cout << -1 << " " << endl;
	}
	return 0;
}