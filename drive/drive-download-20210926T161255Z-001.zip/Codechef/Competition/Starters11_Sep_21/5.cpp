/**
Before the first operation, only the first person can be at the start of the queue.
Before the second operation, the person with maximum power among the first 33 people, which is the person with power 44, is at the front.
Before the third operation, the person with maximum power among the first 55 people is the person with power 55.
And so on.
Try to visualize using pen and paper.
*/

#include<bits/stdc++.h>

using namespace std;
unordered_map<int,bool> umap;

struct comp{
	bool operator()(pair<int,int> a, pair<int,int> b)
	{
		if(a.first == b.first)
			return a.second > b.second;
		return a.first < b.first;
	}
};

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		vector<pair<int,int>> vec;
		for(int i=0;i<n;i++)
		{
			int val ;
			cin >> val;
			vec.push_back({val , i+1});
		}
		vector<pair<int,int>> v;
		int ctr = 1;
		int itr = 1;
		priority_queue<pair<int,int>,vector<pair<int ,int>>,comp> pq;
		reverse(vec.begin(),vec.end());
		pq.push({vec.back().first , vec.back().second});
		vec.pop_back();
		while(vec.size()!=0)
		{
			v.push_back({pq.top().second , ctr++});
			pq.pop();
			if(vec.size() !=0)
			{
				pq.push({vec.back().first,vec.back().second});
				vec.pop_back();
			}
			if(vec.size() !=0)
			{
				pq.push({vec.back().first,vec.back().second});
				vec.pop_back();
			}
		}
		while(!pq.empty())
		{
			v.push_back({pq.top().second , ctr++});
			pq.pop();
		}
		sort(v.begin(),v.end());
		for(auto i:v)
			cout << i.second << " ";
		cout << endl;
	}
	return 0;
}