///marked
#include<bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        unordered_map<int, int> umap;
        int arr[4];
        for(int i=0;i<4;i++){
            cin >> arr[i];
            umap[arr[i]]++;
        }
        if(umap.size() == 4 || umap.size() == 3)
            cout << 2 << endl;
        else if(umap.size() == 2)
        {
            if(umap[arr[0]]==2)
                cout << 2 << endl;
            else
                cout << 1 << endl;
        }
        else
            cout << 0 << endl;


    }
    return 0;
}
