#include<bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long ctr = 0;
        long n , p , k;
        cin >> n>> p>> k;
        long pos ;
        if(p %k == 0)
        {
            cout << p/k +1 << endl;
            continue;
        }
        long  one =1;
        ctr = (n-1)/k +one;
        pos = p/k;
        pos++;
        long val = (n-1)%k;
        long val2 = (p%k);
        long day = ctr;
        if(val2<=val)
        {
            day += ((val2-1)*ctr);
        }
        else if(val2 > val)
        {
            day += (val)*ctr;
            val = val2 - val -1;
            day += (val*(ctr-1));
        }
        day += pos;
        cout << day << endl;
    }

    return 0;
}
