/**
5
43 26 22 11 30
26 4 41 46 49
*/

#include<bits/stdc++.h>

using namespace std;

struct kaam{
    long index;
    long ai;
    long ti;
};


kaam arr[300010];

bool comp(kaam a , kaam b)
{
    if(a.ti == b.ti)
        return a.index < b.index;
    return a.ti < b.ti;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long n;
        cin >> n;
        for(long i=0;i<n;i++){
            cin >> arr[i].ai;
            arr[i].index = i+1;
        }
        for(long i=0;i<n;i++)
            cin >> arr[i].ti;
        sort(arr,arr+n,comp);
        priority_queue<pair<int,int>> pq;
        vector<vector<int>> vec;
        long counts =0;
        for(int i=n-1;i>=0;i--)
        {
            int dura = arr[i].ti - (i == 0 ? 0:  arr[i-1].ti );
            pq.push({arr[i].ai , arr[i].index});
            if(dura && !pq.empty())
            {
                int time = pq.top().first;
                int index = pq.top().second;
                pq.pop();
                if(dura >= time)
                {
                    counts ++ ;
                    dura -= time;
                    vector<int> ans;
                    ans.push_back(index);
                    ans.push_back(arr[i-1].ti-1);
                    ans.push_back(arr[i].ti);
                    vec.push_back(ans);
                }
                else{
                    dura = 0;
                    time -= dura;
                    pq.push({time,index});
                    vector<int> ans;
                    ans.push_back(index);
                    ans.push_back(arr[i-1].ti);
                    ans.push_back(arr[i].ti);
                    vec.push_back(ans);
                }
            }
        }
        cout << counts << endl;
        for(auto i:vec)
        {
            for(auto j:i)
            {
                cout << j << " ";
            }
            cout << endl;
        }


    }
    return 0;
}
