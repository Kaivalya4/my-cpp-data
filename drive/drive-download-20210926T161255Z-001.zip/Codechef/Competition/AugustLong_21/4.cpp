///marked
/**
a = qb + c  ---1
b = tc     ---2
=> c | a and c | b
loop1 : i:1 to n => to find all c
loop2 : we have to find d . since c|b hence => j=i ; j<=n ; j+=i
 From loop1 we have c and from loop2 we have b
loop3 : now c|a . So we can do : k=i; k<=n ;k+=i . But we can do better in loop3
    from equation 1 we can say that a = c + (multiple of b)  . So optimized loop -
    k = i ;k<=n;k+=j
*/
#include<bits/stdc++.h>

using namespace std;

int main()
{
    long ctr = 0;
    int t;
    cin >> t;
    while(t--)
    {
        ctr =0;
        int n;
        cin >> n;
        for(int i=1;i<=n;i++)
        {
            for(int j=i; j<=n;j+=i)
            {
                for(int k=i;k<=n;k+=j)
                {
                    int c = i;
                    int b = j;
                    int a = k;
                    int val = a%b;
                    if(val == c)
                    {
                        ctr++;
                    }
                }
            }
        }

        cout << ctr << endl;
    }
    return 0;
}

