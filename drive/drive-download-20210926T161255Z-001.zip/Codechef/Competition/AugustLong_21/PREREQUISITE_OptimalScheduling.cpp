/**
Cp-Algorithms :
QUESTION:Suppose, we have a set of jobs, and we are aware of every job�s deadline and its duration.
    The execution of a job cannot be interrupted prior to its ending.
    It is required to create such a schedule to accomplish the biggest number of jobs.

Answer:
The solution is greedy. Similar to "N-meetings in one room" or "Activity Selection Problem" , we prefer
that job first whose deadline is early -
    -> Sort the data on basis of deadline in ascending order.

We start looking at the jobs in descending order of deadlines.Also, let�s create a queue q,
in which we�ll gradually put the jobs and extract one with the least run-time
(for instance, we can use set or priority_queue). Initially, q is empty.

Suppose, we�re looking at the i-th job. First of all, let�s put it into q.
Let�s consider the period of time between the deadline of i-th job and the deadline of i-1th job.
That is the segment of some length T. We will extract jobs from q (whose duration is less will be poped out first and then is used to fill T)
and execute them until the whole segment T is filled.
Important: if at any moment of time the extracted job can only be partly executed until segment T is filled,
then we execute this job partly just as far as possible, i.e., during the T time,
and we put the remaining part of a job back into q.


*/

/**
struct Job{
    int duration;
    int deadline;
    int index;

    bool operator<>(Job o) const{   ///we can define our custom comparator if neede just like we do for other structs
        return deadline < o.deadline;
    }
};

vector<int> scheduling(vector<Job> jobs)
{
    sort(jobs.begin() , jobs.end());

    priority_queue<pair<int,int> , vector<pair<int,int>> , greater<pair<int,int>>> pq;
    vector<int> schedules;
    for(int i=jobs.size() -1 ; i>=0; i--){
        ///we find T
        int dura = jobs[i].deadline - (i?jobs[i-1].deadline : 0)   ///if i=0 we take 0
        ///push i-th job in minheap
        pq.push({jobs[i].duration , jobs[i].index});

        if(dura && !pq.empty()){
            auto it = pq.top();
            pq.pop();
            ///if we have job that has duration less than T
            ///and can be fitted in T
            if(it.first <= dura){
                dura -= it.first;
                schedules.push_back(it.second);
            }
            ///else will fit the job partially
            ///and push rest of the job in minheap.
            else{
                pq.push({it.first - dura , it.index});
                dura =0;
            }
        }
    }
   return schedules;
}
*/

#include<iostream>

using namespace std;

int main()
{
    cout << "Thank YOu" ;
    return 0;
}
