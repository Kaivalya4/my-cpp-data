///marked
///PREREQUISITE LCM
///when we use lcm we get first multiple which are going to be divisible . now multiple of lcm will only be
///divisble , rest will be not.
#include<bits/stdc++.h>

using namespace std;

long long GCD(long long a , long long b)
{
    if(b == 0)
       return a;
    return GCD(b , a%b);
}

long long LCM(long long a  , long long b)
{
    long long gcd = GCD(a , b);
    long long lcm = (a/gcd)*b;
    return lcm;
}

bool compare(pair<long , long> x ,pair<long , long> y){
    return x.first > y.first;
}

int main()
{
    long ctr = 0;
    int t;
    cin >> t;
    while(t--)
    {
        long n;
        cin >> n;
        int m;
        cin >> m;
        vector<pair<long  , long>> vec;
        for(int i=1; i<=m;i++)
        {
            int x,y;
            cin >> x >> y;
            vec.push_back({x,y});
        }
        long long sum = 0;
        sort(vec.begin(),vec.end(),compare);
        sum = (n -  n/(vec[0].second))*(vec[0].first) ;
        long val =  n/(vec[0].second);
        long b = vec[0].second;
        for(int i=1;i<m && val>0;i++)
        {
            long  a = vec[i].second;
            long lcm = LCM(a,b);
            sum += (val - n/lcm)*(vec[i].first);
            val = n/lcm;
            b = lcm;
        }
        cout << sum << endl;

    }
    return 0;
}
