/**
How to find lcm -
1) using prime factorization

2) using simple loop -
    int lcm(int a , int b)
    {
        if(a>b)
            swap(a,b);
        for(int i=b;i<=a*b;i+=b)
        {
            if(i%a == 0)
                return i;
        }
        return a*b;
    }

3) using formula lcm(a,b) = (a*b)/gcd(a,b) . To avoid overflow -
    lcm(a,b) = (a/gcd(a,b)) * b ;
*/
#include<bits/stdc++.h>

using namespace std;

int main()
{
    cout << "Thank you";
    return 0;
}
