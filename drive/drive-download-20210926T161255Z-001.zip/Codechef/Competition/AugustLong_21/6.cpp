/**
5
43 26 22 11 30
26 4 41 46 49
*/
///see my commented code . we will extend the same comcept using heap.
/**
suppose two people leave at tim 10 one take 8 unit charge one take 4 unit charge. It will be better to
give second person time first because then we will get extra time to allot for others. --- (* see in code)
*/

#include<bits/stdc++.h>

using namespace std;

struct kaam{
    long index;
    long ai;
    long ti;
};


kaam arr[300010];

bool comp(kaam a , kaam b)
{
    if(a.ti == b.ti)
        return a.ai < b.ai;
    return a.ti < b.ti;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long long n;
        cin >> n;
        for(long long i=0;i<n;i++){
        	cin >> arr[i].ai;
        	arr[i].index  = i;
		}
        for(long long j=0;j<n;j++)
        	cin >> arr[j].ti;
        sort(arr , arr+n , comp);
        priority_queue<pair<long long, long long>> pq; ///we want a max heap so that person who has been allocated but has more chargetime comes first
        long long prv = 0; ///time at which previous person leave
        long long Gap = 0; ///after allocation : timeLeft after allocation of prev person + (time at which current person leave - time at which previous person left)
        for(long long i=0;i<n;i++)
        {
        	long long timeofLeave = arr[i].ti;
        	long long chargeTime = arr[i].ai;
        	Gap += (timeofLeave - prv);
			while(chargeTime > Gap && (!pq.empty()))
			{
				long long tops = pq.top().first;  ///time of person in heap who takes max time
				///(*) - i.e. current person is more suitable than person who was perviously allocated as
				///it has less chargeTime
				if(tops>chargeTime)
				{
					Gap += tops;
					pq.pop();
				} 
				///if current persons chargetime is more then we are sure that if we consider current person
				///for allocation and remove some top person from heap then current person will take more time
				///as chargetime is more and hence Gap will be less we got from current allocation 	
				else
					break;
			} 
			
			if(chargeTime <= Gap)
			{
				Gap -= chargeTime;
				pq.push({chargeTime,i });
			}
			
			prv = timeofLeave;
		}
		vector<kaam> chosenPeople;		
		while(!pq.empty())
		{
			chosenPeople.push_back(arr[pq.top().second]) ;
			pq.pop();
		}
		sort(chosenPeople.begin() , chosenPeople.end() , comp);
		long long time = 0;
		cout << chosenPeople.size() <<  endl;
		for(long long i=0;i<chosenPeople.size();i++)
		{
			cout << chosenPeople[i].index +1 << " " << time << " " << time + chosenPeople[i].ai << endl;
			time += chosenPeople[i].ai;
		}
    }
    return 0;
}

/**
#include<bits/stdc++.h>

using namespace std;

struct kaam{
    int index;
    int ai;
    int ti;
};



bool comp(kaam a , kaam b)
{
    if(a.ti<b.ti)
        return true;
    else
        return a.ai < b.ai;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        kaam arr[n];
        for(int i=0;i<n;i++){
            cin >> arr[i].ai;
            arr[i].index = i+1;
        }
        for(int i=0;i<n;i++)
            cin >> arr[i].ti;
        sort(arr,arr+n,comp);
        int ctr = 0;
        long counts = 0;
        vector<pair<int,pair<int,int>>> ans;
        for(int i=0;i<n;i++)
        {
            if(arr[i].ti < arr[i].ai)
                continue;
            else if(ctr+(arr[i].ai)-1 < arr[i].ti){
            counts ++;
            ans.push_back({arr[i].index,{ctr,ctr+(arr[i].ai)}});
            ctr = ctr+(arr[i].ai) ;
            }
            if(counts == 2*(long)n)
                break;
        }
        cout<< counts << endl;
        for(auto i:ans)
        {
            cout << i.first<< " " << i.second.first << " " << i.second.second << endl;
        }

    }
    return 0;
}

*/