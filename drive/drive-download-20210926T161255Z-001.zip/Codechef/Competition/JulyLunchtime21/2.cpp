///marked
#include<bits/stdc++.h>

using namespace std;

int arr[100001];
int brr[100001];

int main()
{
    long t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        for(int i=0;i<n;i++)
            cin >> arr[i];
        for(int i=0;i<n;i++)
            cin >> brr[i];
        vector<int> vec;
        int mins = INT_MAX;
        for(int i=0;i<n;i++)
        {
            mins = min(mins , (arr[0]+brr[i])%n);
        }
        for(int i=0;i<n;i++)
        {
            if((arr[0] + brr[i])%n == mins)
            {
                vec.push_back(i);
            }
        }
        if(vec.size() == 1)
        {
            int point = vec[0];
            vector<int> ans1;
            for(int i=0 ;i<n;i++)
            {
                ans1.push_back((arr[i] + brr[(point+i)%n])%n);
            }
            for(auto i:ans1)
            {
                cout << i << " ";
            }
            cout << endl;
        }
        else{
            int point = vec[0];
            vector<int> ans1;
            for(int i=0 ;i<n;i++)
            {
                ans1.push_back((arr[i] + brr[(point+i)%n])%n);
            }
            point = vec[1];
            vector<int> ans2;
            for(int i=0 ;i<n;i++)
            {
                ans2.push_back((arr[i] + brr[(point+i)%n])%n);
            }
            if(ans1>ans2)
            {

            for(auto i:ans2)
            {
                cout << i << " ";
            }
            }
            else
            {

            for(auto i:ans1)
            {
                cout << i << " ";
            }
            }
            cout << endl;
        }

    }
    return 0;
}
