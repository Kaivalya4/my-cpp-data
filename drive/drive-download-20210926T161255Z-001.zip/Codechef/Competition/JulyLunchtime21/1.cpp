#include<bits/stdc++.h>

using namespace std;

long long arr[200001];

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long long n;
        cin >>n;
        unordered_map<long long, long long> umap;
        for(int i=0;i<n;i++)
        {
            cin >> arr[i];
            umap[arr[i]] ++;
        }
        long long ans = n*(n-1);
        for(auto i:umap)
        {
            if(i.second > 1)
            {
                long long val = i.second;
                ans = ans -(val*(val-1));
            }
        }
        cout << ans << endl;
    }
    return 0;
}
