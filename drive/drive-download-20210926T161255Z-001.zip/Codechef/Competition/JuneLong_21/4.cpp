//marked

#include<iostream>
#include<vector>
#include<climits>  //for intmax
#include<algorithm>

using namespace std;
int a[1000002];
int b[1000002];

int main()
{
    long t;
    cin >> t;
    while(t--)
    {
        int n , m;
        cin >>n;
        cin >>m;
        int carry = -1;
        vector<int> vecl;
        vector<int> vecr;
        for(int i=1;i<=n; i++)
        {
            cin >> a[i];
        }
        for(int i=1;i<=m;i++)
        {
            cin >> b[i];
        }
        for(int i=1;i<=n;i++)
        {
            if(a[i] == 1)
            {
                vecl.push_back(0);
                carry = i;
            }
            else if(a[i] == 2)
                vecl.push_back(0);
            else if(carry == -1)
                vecl.push_back(INT_MAX);
            else
                vecl.push_back(i-carry);
        }
        carry = -1;
        for(int i=n;i>=1;i--)
        {
            if(a[i] == 2)
            {
                vecr.push_back(0);
                carry = i;
            }
            else if(carry == -1 && a[i] ==0)
            {
                vecr.push_back(INT_MAX);
            }
            else if(a[i] == 1)
                vecr.push_back(0);
            else
            {
                vecr.push_back(carry-i);
            }
        }
        reverse(vecr.begin(),vecr.end());
        for(int k=1;k<=m;k++)
        {
            int val = b[k];
            if(a[0] != 0 && a[val] !=0)
                cout << 0 << " ";
            if(val == 1)
                cout << 0 << " ";
            else if(vecl[val-1] == INT_MAX && vecr[val-1] == INT_MAX)
                cout << -1 << " ";
            else
                cout << min(vecl[val-1] , vecr[val-1]) << " ";
        }
        cout << endl;
    }
    return 0;
}
