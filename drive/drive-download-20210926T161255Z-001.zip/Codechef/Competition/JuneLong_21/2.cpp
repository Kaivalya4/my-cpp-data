#include<iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long D,d,p,q;
        cin >> D >> d >> p >> q;
        long rem = D%d;
        long n = (D-rem)/d;
        long val1 = (n*((2*d*p) + (n-1)*(d*q)))/2 + (rem)*(p+(n*q)) ;
        cout << val1 << endl;
    }
    return 0;
}


