//marked(means redo questions)
#include<iostream>
#include<cmath>

using namespace std;

int mod = 1e9+7;  //1e9 means 10 to the power 9

long long pows(long long a , long long n)
{
    long long res = 1;
    while(n)
    {
        if(n%2){
            res = (res*a)% mod;
            n--;
        }
        a = (a*a)%mod;
        n = n/2;
    }
    return res;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        long long n , m;
        cin >> n >> m;
        long long val = pows(2,n) -1;
        long long val2 = pows(val,m);
        cout << val2%mod << endl;
    }
    return 0;
}
