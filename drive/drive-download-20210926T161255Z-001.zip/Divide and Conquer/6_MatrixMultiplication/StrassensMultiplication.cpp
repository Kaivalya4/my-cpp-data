///see PREREQUISITE for dynamic memory allocation in c++
